# Chat Assistant diagnostic pack

This pack helps you test whether repeated questions inside the business should become a focused AI assistant.

## Use it in three steps

1. Open `prompt.md` in Claude or ChatGPT.
2. Answer the questions one at a time.
3. When the transcript is written, email it to `hello@actai.studio`.

## The nerve

Your people keep answering the same questions.

## Talk to Jonny and Mark

Book a meeting: `/meeting`
